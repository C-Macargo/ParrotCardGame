const tarefas = []; // isso é uma lista (armario) em JS - array

const qtde = Number(prompt("Qual a qtde de tarefas?"));

// enquanto a qtde ainda não for perguntada, repita o código abaixo
let contador = 0;
while( qtde > contador ){
    tarefas.push( prompt("Qual a tarefa?") );
    contador = contador + 1;
}

const lista = document.querySelector('ul');

contador = 0; //0 1 2
while(qtde > contador){
    lista.innerHTML += `<li>${tarefas[contador]}</li>`;
    //contador = contador + 1;
    //contador += 1;
    contador++;
}